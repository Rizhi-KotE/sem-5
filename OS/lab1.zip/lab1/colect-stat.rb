pid = ARGV[0]
top_file = "top_stat_#{pid}"
pidstat_file = "pidstat_stat_#{pid}"
run_top = "top -b -d 1 -n 10 -p #{pid} >> #{top_file}"
run_pidstat = "pidstat -hdrtu -p #{pid} 1 10 >> #{pidstat_file}"
system "#{run_top} & #{run_pidstat}"
puts 'end'