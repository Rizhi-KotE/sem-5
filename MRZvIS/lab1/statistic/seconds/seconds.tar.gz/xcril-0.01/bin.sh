#!/usr/bin/bash

java -jar teach.jar xcril-small.jpg 8 2 48 40 0.0000008 0.05 &&
mkdir 800000 &&
mv network* 800000 &&
java -jar teach.jar xcril-small.jpg 8 2 48 40 0.0000005 0.05 &&
mkdir 500000 &&
mv network* 500000 &&
init 0